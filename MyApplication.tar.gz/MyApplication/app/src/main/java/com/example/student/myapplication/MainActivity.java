package com.example.student.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.View;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myView v;
        v = new myView(this);
        setContentView(v);

    }
    class myView extends View {
        private Paint paint;
        public myView(Context context) {
            super(context);
            init();
        }
        private void init() {
            paint = new Paint();
            paint.setStyle(Paint.Style.FILL_AND_STROKE);
            invalidate(); //causes a canvas draw
        }
        protected void onDraw(Canvas canvas) {
            paint.setColor(Color.rgb(255,255,0));
            paint.setStyle(Paint.Style.FILL);
            canvas.drawRect(0, 500, 500, 50, paint);
            paint.setTextSize(100);
            paint.setColor(Color.BLACK);
            canvas.drawText("3350 Lab-11", 100, 100, paint);
        }
    }

}
